# Masjid Ibn Abass Website

This repository hosts the website for **Masjid Ibn Abass**.

## Features
- Prayer times table with clear alignment and responsive design.
- Weekly class timetable.
- Mobile-friendly layout with dark mode and menu toggle.
- "Join Us on Telegram" button integrated into the hero section.

## Deployment
This site is designed to be deployed using **GitHub Pages**.

1. Push this repository to GitHub.
2. Go to **Settings → Pages**.
3. Select the branch (`main`) and folder (`root`) to serve your site.
4. Your site will be live at: `https://<your-username>.github.io/<repo-name>/`

## File structure
- `index.html` — main site entry point
- `README.md` — documentation
- `LICENSE` — license file
- `.gitignore` — ignore common unnecessary files

---

© Masjid Ibn Abass, built for the community.
